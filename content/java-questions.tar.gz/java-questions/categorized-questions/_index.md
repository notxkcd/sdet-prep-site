---
title: "Categorized Interview Questions"
date: 2026-01-30
draft: false
---

# Categorized Questions

Explore interview questions organized by technology and process.

- **[Agile](agile/)**
- **[Api Testing](api-testing/)**
- **[Appium Mobile](appium-mobile/)**
- **[Cucumber](cucumber/)**
- **[Framework Architecture](framework-architecture/)**
- **[General Other](general-other/)**
- **[General Qa](general-qa/)**
- **[Git Github](git-github/)**
- **[Jenkins Cicd](jenkins-cicd/)**
- **[Selenium](selenium/)**
- **[Sql Database](sql-database/)**
- **[Testing Process Manual](testing-process-manual/)**
- **[Testng](testng/)**
