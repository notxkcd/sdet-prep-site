---
title: "Selenium Interview Questions"
date: 2026-01-30
draft: false
categories: ["Selenium"]
---

## Beginner (Locators & Basics)
1. [What is Selenium?](#1-what-is-selenium)
2. [What is the role of Selenium/WebDriver in automation testing?](#2-what-is-the-role-of-seleniumwebdriver-in-automation-testing)
3. [What are the components of Selenium?](#3-what-are-the-components-of-selenium)
4. [What are the different types of locators in Selenium?](#4-what-are-the-different-types-of-locators-in-selenium)
5. [Which locator do you use most in your project?](#5-which-locator-do-you-use-most-in-your-project)
6. [What is the difference between `/` and `//` in XPath?](#6-what-is-the-difference-between-and-in-xpath)
7. [Explain relative and absolute XPath?](#7-explain-relative-and-absolute-xpath)
8. [What are the different types of XPath?](#8-what-are-the-different-types-of-xpath)
9. [How do you launch a browser in Selenium?](#9-how-do-you-launch-a-browser-in-selenium)
10. [What is the difference between `driver.get()` and `driver.navigate().to()`?](#10-what-is-the-difference-between-driverget-and-drivernavigateto)
11. [What is the difference between `close()` and `quit()`?](#11-what-is-the-difference-between-close-and-quit)
12. [What is the return type of `getWindowHandles()`?](#12-what-is-the-return-type-of-getwindowhandles)
13. [How do you handle dropdowns in Selenium?](#13-how-do-you-handle-dropdowns-in-selenium)
14. [How do you handle alerts and pop-ups in Selenium?](#14-how-do-you-handle-alerts-and-pop-ups-in-selenium)
15. [How do you take a screenshot in Selenium?](#15-how-do-you-take-a-screenshot-in-selenium)

---




## Questions with Answers

### 1. What is Selenium?
**Answer**: Selenium is an open-source suite of tools used for automating web browsers. It supports multiple programming languages (Java, Python, C#, etc.) and browsers (Chrome, Firefox, Safari).

### 2. What is the role of Selenium/WebDriver in automation testing?
**Answer**: WebDriver is the component that communicates directly with the web browser using its native engine. It automates user interactions like clicking, typing, and navigating.

### 3. What are the components of Selenium?
**Answer**:
1. **Selenium IDE**: Browser extension for recording/playback.
2. **Selenium WebDriver**: Modern API for script-based automation.
3. **Selenium Grid**: Used for parallel and remote execution.

### 4. What are the different types of locators in Selenium?
**Answer**: `ID`, `Name`, `ClassName`, `TagName`, `LinkText`, `PartialLinkText`, `CSS Selector`, and `XPath`.

### 5. Which locator do you use most in your project?
**Answer**: I prefer **ID** because it's the fastest and most stable. If ID is missing, I use **CSS Selector** for performance or **XPath** for complex hierarchical searches.

### 6. What is the difference between `/` and `//` in XPath?
**Answer**:
- `/`: Absolute XPath. Starts from the root and searches directly (Single slash).
- `//`: Relative XPath. Searches anywhere in the HTML document (Double slash).

### 7. Explain relative and absolute XPath?
**Answer**:
- **Absolute**: Long path starting from `<html>`. Brittle because it breaks if any tag changes.
- **Relative**: Starts from a specific point. Robust and much easier to maintain.

### 8. What are the different types of XPath?
**Answer**:
1. **Basic XPath**: Using attributes like `@id` or `@name`.
2. **Contains()**: For partial text matching.
3. **Starts-with()**: Matching elements that start with specific text.
4. **XPath Axes**: Searching siblings, parents, or ancestors.

### 9. How do you launch a browser in Selenium?
**Answer**:
```java
WebDriver driver = new ChromeDriver();
driver.get("https://google.com");
```

### 10. What is the difference between `driver.get()` and `driver.navigate().to()`?
**Answer**:
- `get()`: Wait until the page is fully loaded. Does not store history.
- `navigate().to()`: Does not wait for the page to load. Stores history (back/forward).

### 11. What is the difference between `close()` and `quit()`?
**Answer**:
- `close()`: Closes the current browser window only.
- `quit()`: Closes all windows and kills the WebDriver session (Clean exit).

### 12. What is the return type of `getWindowHandles()`?
**Answer**: `Set<String>`. It returns a set of unique alpha-numeric window handles.

### 13. How do you handle dropdowns in Selenium?
**Answer**: By using the **Select** class:
```java
Select s = new Select(element);
s.selectByVisibleText("Option");
```

### 14. How do you handle alerts and pop-ups in Selenium?
**Answer**: Using `driver.switchTo().alert()`:
- `accept()`: Click OK.
- `dismiss()`: Click Cancel.
- `getText()`: Read message.

### 15. How do you take a screenshot in Selenium?
**Answer**: By casting driver to `TakesScreenshot`:
```java
File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
FileUtils.copyFile(src, new File("path.png"));
```

---

## Intermediate (Wait, Frames & Actions)
1. [Explain the difference between implicit wait and explicit wait?](#wait-difference)
2. [What is fluent wait and when do you use it?](#fluent-wait)
3. [How do you handle frames in Selenium?](#handle-frames)
4. [How do you handle windows/multiple tabs in Selenium?](#handle-windows)
5. [What is the `Actions` class and what are its methods?](#actions-class)
6. [How do you simulate mouse hover actions in Selenium?](#mouse-hover)
7. [How do you perform drag and drop in Selenium?](#drag-and-drop)
8. [What is the `Select` class and how do you use it?](#select-class)
9. [How do you handle dynamic elements in Selenium?](#dynamic-elements)
10. [What are common exceptions you have faced in Selenium?](#selenium-exceptions)
11. [What is `StaleElementReferenceException` and how do you handle it?](#stale-element-exception)
12. [How do you handle a file upload in Selenium?](#file-upload)
13. [How do you execute JavaScript in Selenium?](#javascript-executor)
14. [How do you identify the color of a web element?](#element-color)
15. [How do you check if an element is enabled or displayed?](#element-state)

## Questions with Answers

### Difference between implicit wait and explicit wait?
**Answer**:
- **Implicit**: Global wait applied to every element search.
- **Explicit**: Applied only to a specific element for a specific condition (e.g., `visibilityOf`).

### What is fluent wait?
**Answer**: A type of explicit wait that also defines the **polling frequency** (how often to check) and can ignore specific exceptions (like `NoSuchElementException`).

### How do you handle frames in Selenium?
**Answer**: Using `driver.switchTo().frame()`:
- By Index.
- By Name/ID.
- By WebElement.
- Switch back using `defaultContent()`.

### How do you handle multiple tabs?
**Answer**:
1. Get parent window ID: `getWindowHandle()`.
2. Get all window IDs: `getWindowHandles()`.
3. Switch using `driver.switchTo().window(id)`.

### What is the `Actions` class?
**Answer**: A class used to perform complex user interactions like **double click**, **drag and drop**, and **mouse hover**. Methods: `moveToElement()`, `dragAndDrop()`, `contextClick()`.

### How do you simulate mouse hover?
**Answer**:
```java
Actions act = new Actions(driver);
act.moveToElement(element).perform();
```

### How do you perform drag and drop?
**Answer**:
```java
act.dragAndDrop(source, target).perform();
```

### What is the `Select` class?
**Answer**: A specialized class for interacting with `<select>` tags (dropdowns). Methods: `selectByIndex()`, `selectByValue()`, `isMultiple()`.

### How do you handle dynamic elements?
**Answer**:
1. Use dynamic XPath (e.g., `contains()`).
2. Use XPath axes (Parent/Sibling).
3. Use Explicit Wait.

### What are common exceptions in Selenium?
**Answer**: `NoSuchElementException`, `StaleElementReferenceException`, `ElementNotInteractableException`, `TimeoutException`.

### What is `StaleElementReferenceException`?
**Answer**: Occurs when an element found earlier is no longer present in the DOM (e.g., page refresh). Fix: Refind the element or use Page Factory.

### How do you handle a file upload?
**Answer**: By using `sendKeys()` on the `<input>` element with the file path. (No need to click the "Browse" button).

### How do you execute JavaScript?
**Answer**: Using the **JavascriptExecutor** interface:
```java
JavascriptExecutor js = (JavascriptExecutor) driver;
js.executeScript("window.scrollBy(0,500)");
```

### How do you identify the color of a web element?
**Answer**: Use `element.getCssValue("color")`. It returns the color in RGBA format.

### How do you check if an element is enabled or displayed?
**Answer**: Using boolean methods: `isDisplayed()`, `isEnabled()`, and `isSelected()`.

---

## Advanced (Frameworks & Optimization)
1. [What is the Page Object Model (POM)?](#explain-pom)
2. [What is the difference between POM and Page Factory?](#pom-vs-pagefactory)
3. [How do you achieve parallel execution in Selenium?](#parallel-execution)
4. [Explain Selenium Grid and its usage?](#selenium-grid)
5. [What are assertions and how do you use them in your framework?](#assertions-usage)
6. [Explain your framework architecture in detail?](#framework-architecture)
7. [How do you manage test data in your Selenium project?](#test-data-management)
8. [How do you handle synchronization issues in Selenium?](#synchronization-issues)
9. [What is a WebDriverEventListener?](#webdriver-listener)
10. [What is headless testing and how do you perform it?](#headless-testing)
11. [How do you validate broken links on a webpage?](#broken-links)
12. [Scenario: XPath is changing dynamically, how do you handle it?](#dynamic-xpath-scenario)
13. [Scenario: An element is loaded but not interactable?](#not-interactable-scenario)

## Questions with Answers

### What is the Page Object Model (POM)?
**Answer**: A design pattern that improves test maintenance and reduces duplication by creating an object repository for web elements.

### Difference between POM and Page Factory?
**Answer**: POM is the pattern; Page Factory is the tool (part of Selenium) that implements the pattern using lazy initialization (`@FindBy`).

### How do you achieve parallel execution?
**Answer**: By configuring the `testng.xml` file with `parallel="methods"` and using **ThreadLocal** to keep the WebDriver instance safe.

### Explain Selenium Grid?
**Answer**: It allows running tests on different machines (Hub and Nodes) across different browsers and OSs simultaneously.

### What are assertions?
**Answer**: They are used to verify the expected result vs. the actual result. I use **Hard Assert** for critical failures and **Soft Assert** for non-blocking checks.

### Explain your framework architecture?
**Answer**: My framework is **Cucumber BDD** with **Maven**. It uses **Page Factory**, **TestNG** for assertions, and **Extent Reports**. I use **Jenkins** for CI/CD.

### How do you manage test data?
**Answer**: I use **Apache POI** for Excel, **JSON** for complex objects, and **Properties** files for constants.

### How do you handle synchronization issues?
**Answer**: By using **Explicit Waits** instead of `Thread.sleep()`, ensuring the script only proceeds when the element is truly ready.

### What is a WebDriverEventListener?
**Answer**: An interface that lets you listen to WebDriver events (like `beforeNavigateTo`) to perform logging or custom actions.

### What is headless testing?
**Answer**: Running browser automation without a GUI. Use `ChromeOptions` with `options.addArguments("--headless")`.

### How do you validate broken links?
**Answer**:
1. Get all `<a>` tags.
2. Get the `href` attribute.
3. Use the `HttpURLConnection` class to check the response code (404/500 = Broken).

### Scenario: XPath is changing dynamically?
**Answer**: Use **contains()** or **starts-with()** functions, or locate a stable parent/sibling and use XPath axes.

### Scenario: Element is loaded but not interactable?
**Answer**:
1. Element might be hidden.
2. Element might be disabled.
3. Another element might be overlapping (use `Actions` or `JavascriptExecutor` to click).
