---
title: "GPG for Email Encryption"
weight: 9
---

# 📧 GPG for Email Encryption (How It Actually Works)

## Mental model (read this once)

Email encryption with GPG has **two separate actions**:

1. 🔒 **Encrypt** → only the recipient can read it
2. ✍️ **Sign** → proves *you* sent it

You usually do **both**.

---

## 1️⃣ What you need before anything works

You already need:

* Your **GPG keypair** (you have this)
* The **recipient’s public key**

Without the recipient’s public key → encryption is impossible.

---

## 2️⃣ Get someone’s public key

### Option A: They send it to you

File ends with:

```
.asc
```

Import it:

```bash
gpg --import alice-public.asc
```

---

### Option B: From a keyserver

```bash
gpg --search-keys alice@email.com
```

Pick the correct key → confirm.

⚠️ **Always verify fingerprint out-of-band**
(chat, call, website).

---

## 3️⃣ Verify the key (VERY important)

```bash
gpg --fingerprint alice@email.com
```

Compare with what Alice tells you.

If it matches → trust it.

---

## 4️⃣ Encrypt + sign an email (core command)

Create your message:

```bash
nano message.txt
```

Then:

```bash
gpg --encrypt --sign -r alice@email.com message.txt
```

This produces:

```
message.txt.gpg
```

What happened:

* 🔒 Encrypted with Alice’s public key
* ✍️ Signed with your private key

---

## 5️⃣ Send it via email (how people actually do it)

### Option A: Attach the `.gpg` file

Most common & simplest.

---

### Option B: Inline (ASCII armor)

Better for copy/paste:

```bash
gpg --encrypt --sign --armor -r alice@email.com message.txt
```

Output:

```
-----BEGIN PGP MESSAGE-----
...
-----END PGP MESSAGE-----
```

Paste **directly into email body**.

---

## 6️⃣ What the recipient does

Alice receives encrypted message and runs:

```bash
gpg --decrypt message.txt.gpg
```

Or just opens it in her mail client.

She sees:

* Decrypted content
* Signature verification:

```
Good signature from "Your Name"
```

---

## 7️⃣ Reading encrypted email you receive

When someone encrypts mail to **you**:

```bash
gpg --decrypt mail.asc
```

GPG:

* Prompts for your **passphrase**
* Decrypts
* Verifies sender signature (if signed)

---

## 8️⃣ Using GPG with real email clients (recommended)

### Thunderbird (best support)

* Install **Thunderbird**
* Enable **OpenPGP**
* Import your key
* Done

No plugins required anymore.

---

### CLI-only workflow (minimalist)

Use:

* `mutt`
* `neomutt`
* `aerc`

These work *beautifully* with GPG.

---

## 9️⃣ Common mistakes (learn from others’ pain)

❌ Encrypting without verifying fingerprint
❌ Forgetting to include yourself as recipient
❌ Losing private key (no recovery)
❌ Thinking encryption hides metadata (it doesn’t)

---

## 🔍 Important limitation (know this)

GPG **does NOT encrypt**:

* Subject line
* Headers
* Sender / recipient
* Timestamps

Only the **message body + attachments**.

---

## 🔐 Best practices (real-world)

* Always **sign + encrypt**
* Use long passphrases
* Backup your private key offline
* Revoke compromised keys immediately

---

## TL;DR (workflow)

```bash
# import recipient key
gpg --import alice.asc

# verify fingerprint
gpg --fingerprint alice@email.com

# encrypt + sign
gpg --encrypt --sign --armor -r alice@email.com msg.txt
```

---

## One-liner to remember

> **SSH secures connections.
> GPG secures messages — forever.**
