---
title: "Git & Security Mastery"
date: 2026-02-01
weight: 10
---

# Git & Security Mastery

A structured learning path for mastering Git workflows and advanced security practices.

## Learning Path

1. **[Git Basics 101](git-basics/)** - Fundamental commands and local workflow.
2. **[GitHub Authentication (SSH vs HTTPS)](github-authentication/)** - Connecting your local repo to the world.
3. **[Why SSH Keys are Safer](ssh-keys-safety/)** - Understanding the security model behind SSH.
4. **[GPG: Generate Keys Guide](gpg-keys-guide/)** - Setting up your cryptographic identity for signing.
5. **[GPG vs SSH: When to Use Which](gpg-vs-ssh/)** - Clarifying the roles of access vs. identity.
6. **[Hardware-backed GPG (YubiKey)](hardware-gpg-yubikey/)** - The gold standard for securing your private keys.
7. **[How Supply-Chain Attacks Happen](supply-chain-attacks/)** - The real-world threats that make these tools necessary.
8. **[Why Git Uses Ancient Auth](git-ancient-auth/)** - Historical context and Git's design philosophy.
9. **[GPG for Email Encryption](gpg-email-encryption/)** - Expanding your GPG skills to secure communications.