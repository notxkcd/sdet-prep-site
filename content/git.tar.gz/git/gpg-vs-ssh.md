---
title: "GPG vs SSH — When to Use Which"
weight: 5
---

# 🔑 GPG vs SSH — When to Use Which (No BS)

## One-line rule (memorize this)

> **SSH = authenticate to servers**
> **GPG = prove authorship & trust**

They solve **different problems**.

---

## 🧠 Mental model

| Tool | Question it answers                       |
| ---- | ----------------------------------------- |
| SSH  | “Are *you* allowed to connect right now?” |
| GPG  | “Did *you* really create this thing?”     |

---

## 🔐 SSH — what it’s actually for

### Primary uses

* `git push / pull`
* `ssh user@server`
* Deploying, tunneling, port forwarding

### What SSH does

* Proves you own a **private key**
* Grants **access**
* Session-based authentication

### What SSH does **NOT** do

* ❌ Prove authorship later
* ❌ Leave permanent identity proof
* ❌ Survive copy/paste of content

### Example

```bash
git push
```

GitHub says:

> “Yes, this key is allowed to push.”

Later?

> “No idea who authored those commits.”

---

## 🔏 GPG — what it’s actually for

### Primary uses

* Signing Git commits & tags
* Verifying releases
* Encrypting messages/files

### What GPG does

* Attaches a **cryptographic signature**
* Verifiable **forever**
* Survives mirrors, forks, copies

### What GPG does **NOT** do

* ❌ Authenticate network sessions
* ❌ Replace SSH for Git access

### Example

```bash
git commit -S -m "Fix race condition"
```

Anyone can later verify:

> “This commit was signed by Mohammed Shahid.”

---

## ⚔️ Side-by-side (important)

| Feature       | SSH          | GPG              |
| ------------- | ------------ | ---------------- |
| Purpose       | Access       | Identity         |
| Time          | Live session | Permanent        |
| Used for      | Push / login | Signing / trust  |
| Revocation    | Remove key   | Revoke signature |
| GitHub badge  | ❌            | ✅ “Verified”     |
| Survives fork | ❌            | ✅                |

---

## 🧩 Real-world Git workflow (best practice)

✔️ **SSH**

```bash
git push
```

✔️ **GPG**

```bash
git commit -S
```

You should use **both**.

---

## 🚨 Why GitHub doesn’t allow GPG instead of SSH

Because:

* GPG is **slow & interactive**
* Not designed for live sessions
* Bad UX for frequent operations

SSH is optimized for:

* Fast handshakes
* Repeated connections
* Agent forwarding

---

## 🧠 Trust model difference (this is key)

### SSH trust

> “I trust this machine *right now*.”

### GPG trust

> “I trust this identity *forever*.”

---

## 🎯 When to use which (cheat sheet)

### Use SSH when:

* Pushing/pulling code
* Logging into servers
* CI/CD auth
* Automation

### Use GPG when:

* Signing commits/tags
* Publishing releases
* Proving authorship
* Open-source work

---

## 🔥 Advanced (optional but cool)

* SSH keys can be **ephemeral**
* GPG keys should be **long-lived**
* Hardware keys (YubiKey) can do **both**

---

## TL;DR (tattoo this)

> **SSH gets you in.**
> **GPG proves it was you.**
