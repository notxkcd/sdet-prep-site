---
title: "GitHub Authentication Tutorial (SSH vs HTTPS)"
weight: 2
---

#  📘 GitHub Authentication Tutorial (SSH vs HTTPS)

> **Goal:**
> Make Git use **SSH keys** so you:
>
> * Don’t enter username/password every push
> * Use your **SSH key passphrase**
> * Never deal with GitHub PAT nonsense again

---

## 0️⃣ Mental model (read this once)

Git has **two ways** to talk to GitHub:

| Method | What it asks     | Uses SSH key? |
| ------ | ---------------- | ------------- |
| HTTPS  | username + token | ❌ No          |
| SSH    | key + passphrase | ✅ Yes         |

👉 If Git asks for **username/password**,
👉 you are **NOT using SSH**.

---

## 1️⃣ Check what your repo is using (ALWAYS first)

Inside the repo:

```bash
git remote -v
```

### If you see:

```text
https://github.com/username/repo.git
```

❌ HTTPS (will ask for username/password)

### If you see:

```text
git@github.com:username/repo.git
```

✅ SSH (will ask for passphrase)

---

## 2️⃣ Generate an SSH key (one-time setup)

Check first:

```bash
ls ~/.ssh
```

If you already see:

```
id_ed25519
id_ed25519.pub
```

👉 skip this step.

Otherwise:

```bash
ssh-keygen -t ed25519
```

* Press Enter for default location
* Set a **passphrase** (important)

---

## 3️⃣ Add SSH key to GitHub (one-time)

Copy your public key:

```bash
cat ~/.ssh/id_ed25519.pub
```

Then on GitHub:

```
Settings → SSH and GPG keys → New SSH key
```

Paste → Save.

---

## 4️⃣ Test SSH connection (VERY IMPORTANT)

```bash
ssh -T git@github.com
```

### Expected output:

```text
Hi <username>! You've successfully authenticated...
```

If this fails → stop here and fix before continuing.

---

## 5️⃣ Convert an existing repo from HTTPS → SSH

Inside the repo:

```bash
git remote set-url origin git@github.com:USERNAME/REPO.git
```

Example (yours):

```bash
git remote set-url origin git@github.com:notxkcd/sdet-prep-site.git
```

Verify:

```bash
git remote -v
```

---

## 6️⃣ Push (what should happen now)

```bash
git push
```

✔️ Git asks for **SSH key passphrase**
❌ No username
❌ No password

That’s the **correct behavior**.

---

## 7️⃣ Avoid retyping passphrase (per session)

Load key into agent:

```bash
ssh-add ~/.ssh/id_ed25519
```

You enter passphrase **once per login**.

---

## 8️⃣ Make SSH automatic forever (recommended)

Create/edit:

```bash
nano ~/.ssh/config
```

Add:

```ssh
Host github.com
  HostName github.com
  User git
  IdentityFile ~/.ssh/id_ed25519
  AddKeysToAgent yes
```

Now Git just works™.

---

## 9️⃣ Common failure patterns (recognize instantly)

### ❌ “GitHub asks for username/password”

→ Repo is HTTPS
✔️ Fix: `git remote set-url origin git@github.com:...`

---

### ❌ “Permission denied (publickey)”

→ SSH key not added to GitHub
✔️ Fix: Step 3

---

### ❌ “Works on one machine, not another”

→ SSH key exists only on first machine
✔️ Fix: Generate key again on new machine

---

## 🔟 Golden rules (tattoo these)

* 🔑 **SSH is per machine**, not per GitHub account
* 🌍 Each cloned repo has its **own remote URL**
* 🧠 Git NEVER auto-switches HTTPS → SSH
* 🧪 `git remote -v` tells the truth

---

## Ultra-short checklist (panic mode)

```bash
git remote -v
ssh -T git@github.com
git remote set-url origin git@github.com:user/repo.git
git push
```

---


## Why GitHub killed passwords (the *actual* reasons)

### 1️⃣ Passwords were a security disaster

People reused passwords **everywhere**.

When one random site leaked:

* Attackers tried the same password on GitHub
* Repos got hijacked
* Malware got injected into open-source projects

This is called **credential stuffing** — and it worked *way too well*.

---

### 2️⃣ Git has no real way to do 2FA

Git (the protocol) was designed **before** modern auth.

Over HTTPS:

* Git can only send `username + secret`
* No browser
* No OTP prompt
* No hardware key

So if passwords stayed:

> **2FA would be meaningless**

---

### 3️⃣ Personal Access Tokens are scoped

Passwords give **full account access**.

PATs can be:

* Read-only
* Repo-specific
* Time-limited
* Revoked instantly

If a token leaks → **blast radius is tiny**.

Passwords? Total account takeover.

---

### 4️⃣ Open-source supply chain attacks scared everyone

One compromised maintainer =

* Backdoored libraries
* Millions of users affected

GitHub decided:

> “Passwords are not acceptable risk anymore.”

This wasn’t theoretical — it already happened.

---

### 5️⃣ SSH is cryptographically better (and older than GitHub)

SSH:

* Never sends secrets over the wire
* Uses challenge–response
* Private key never leaves your machine

Even if GitHub is breached:

* Your private key is still safe

---

## So what GitHub actually did

In 2021:

* ❌ Disabled account passwords for Git over HTTPS
* ✅ Forced **PATs or SSH**
* ❌ Broke old tutorials (sad but necessary)

---

## TL;DR (memorize this)

| Method   | Security   | Why               |
| -------- | ---------- | ----------------- |
| Password | ❌ Terrible | Reused, phishable |
| PAT      | ⚠️ Better  | Scoped, revocable |
| SSH      | ✅ Best     | Keys never sent   |

---

## The quiet truth

> GitHub didn’t *kill* passwords.
> Passwords killed themselves.
