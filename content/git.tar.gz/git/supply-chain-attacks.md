---
title: "How supply-chain attacks actually happen"
weight: 7
---

# 🔥 How supply-chain attacks actually happen

> **Supply-chain attack** =
> Compromising *trust*, not code.

Attackers don’t “hack users”.
They **become someone you already trust**.

---

## 1️⃣ Maintainer account takeover (most common)

### How it happens

* Maintainer reuses password
* Phished GitHub / npm credentials
* No 2FA
* Leaked token in CI logs

Attacker gets:

* Push access
* Publish rights

They add:

```js
if (process.env.CI) stealSecrets();
```

Nobody notices — tests still pass.

### Why this works

* Maintainers are overworked
* Old projects have weak security
* One person controls releases

---

## 2️⃣ Dependency confusion (nasty & clever)

### How it works

Internal company uses:

```json
"dependencies": {
  "core-utils": "^1.2.0"
}
```

Attacker publishes:

```
core-utils@99.99.99
```

Public registry wins.

Boom:

* Malware installed in CI
* Secrets exfiltrated

No exploit. Just naming.

---

## 3️⃣ Typosquatting (boring but effective)

Examples:

* `react-dom` → `react_d0m`
* `urllib3` → `urllib33`

One character off.

People install it **by accident**.

Malware runs during install.

---

## 4️⃣ Malicious install scripts (very common)

In `package.json`:

```json
"scripts": {
  "postinstall": "node backdoor.js"
}
```

Runs:

* On developer machines
* In CI
* In Docker builds

No one audits install scripts.

---

## 5️⃣ Compromised CI/CD pipelines

### Attack path

* Attacker gets CI token
* Injects step:

  * Upload env vars
  * Modify artifacts
* Releases signed binary

Users trust:

* CI
* Signatures
* Checksums

Game over.

---

## 6️⃣ Dormant backdoors (the scariest)

Attacker:

* Contributes harmless PR
* Waits months or years
* Later activates logic remotely

Example pattern:

```c
if (date > 2026 && host == "prod") activate();
```

Looks innocent.
Sleeps quietly.

---

## 7️⃣ Abandoned but popular packages

Maintainer:

* Stops caring
* Leaves email unattended

Attacker:

* Requests maintainership
* Or hijacks account
* Or buys domain tied to email

Millions of installs. Zero resistance.

---

## 🧠 Why this keeps working

Because ecosystems optimize for:

* Speed
* Convenience
* Automation

Attackers exploit:

* Trust inheritance
* Invisible transitive deps
* Human fatigue

---

## 🔐 How defenses actually work (practical)

### 1️⃣ Signed commits & tags (GPG)

Ensures:

* Author authenticity
* No silent hijacks

### 2️⃣ Scoped tokens

* CI tokens limited
* No write unless needed

### 3️⃣ Dependency pinning

Lockfiles:

```text
package-lock.json
Cargo.lock
poetry.lock
```

Stops version surprises.

---

### 4️⃣ Minimal install scripts

Audit:

* `preinstall`
* `postinstall`

Block in CI if possible.

---

### 5️⃣ Reduce dependency count

Every dependency =

> One more maintainer you trust with your system.

---

## 🧠 The uncomfortable truth

> Most supply-chain attacks don’t exploit bugs.
> They exploit **people and process**.

---

## TL;DR

* Attackers don’t break crypto
* They hijack trust
* Automation amplifies damage
* GPG + SSH + minimal deps = real defense
