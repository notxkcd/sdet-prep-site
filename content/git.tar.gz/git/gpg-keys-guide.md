---
title: "GPG: Generate Keys + Use Passphrase"
weight: 4
---

# 🔐 GPG: Generate Keys + Use Passphrase (Practical Guide)

## 0️⃣ What GPG is actually for (mental model)

GPG lets you:

* 🔏 **Sign** things (prove it’s you)
* 🔒 **Encrypt** things (only intended person can read)

For devs, the **#1 use** is:
👉 **Signing Git commits & tags**

---

## 1️⃣ Check if GPG is installed

```bash
gpg --version
```

If not installed:

**Arch / Artix**

```bash
sudo pacman -S gnupg
```

**Ubuntu / Debian**

```bash
sudo apt install gnupg
```

---

## 2️⃣ Generate a GPG key (this is where passphrase comes in)

Run:

```bash
gpg --full-generate-key
```

### Choose these options (recommended)

```
Please select what kind of key you want:
(1) RSA and RSA   ← choose this

What keysize?
4096             ← choose 4096

Key is valid for?
0                ← never expires (or set 1y if you want)

Real name:
Your Name

Email address:
you@email.com
```

### 🔐 Passphrase prompt (IMPORTANT)

* This encrypts your **private key**
* Use a **long sentence**, not a short password

Example:

```
correct horse battery staple but longer
```

You’ll type it twice.

✅ This is **normal and good**.

---

## 3️⃣ Verify your key exists

```bash
gpg --list-secret-keys --keyid-format=long
```

Example output:

```
sec   rsa4096/ABCD1234EFGH5678 2026-02-01
```

👉 Copy the **key ID** (`ABCD1234EFGH5678`)

---

## 4️⃣ Export your public key (for GitHub)

```bash
gpg --armor --export ABCD1234EFGH5678
```

Copy everything:

```
-----BEGIN PGP PUBLIC KEY BLOCK-----
...
-----END PGP PUBLIC KEY BLOCK-----
```

GitHub → **Settings → SSH and GPG keys → New GPG key**

---

## 5️⃣ Tell Git to use GPG (sign commits)

```bash
git config --global user.signingkey ABCD1234EFGH5678
git config --global commit.gpgsign true
git config --global gpg.program gpg
```

Set your identity (must match GPG email):

```bash
git config --global user.name "Your Name"
git config --global user.email "you@email.com"
```

---

## 6️⃣ Make a signed commit (test)

```bash
git commit -m "test signed commit"
```

🔐 GPG will ask for your **passphrase**
That’s expected.

Verify:

```bash
git log --show-signature
```

You should see:

```
Good signature from "Your Name"
```

---

## 7️⃣ Stop passphrase popping up every time (recommended)

Use **gpg-agent** (already included).

### Enable caching

```bash
echo "default-cache-ttl 3600" >> ~/.gnupg/gpg-agent.conf
echo "max-cache-ttl 86400" >> ~/.gnupg/gpg-agent.conf
```

Reload agent:

```bash
gpgconf --kill gpg-agent
```

Now:

* You enter passphrase **once**
* Cached for session/day

---

## 8️⃣ Common mistakes (avoid these)

❌ Using a short passphrase
❌ Email mismatch between Git and GPG
❌ Forgetting to add public key to GitHub
❌ Deleting `~/.gnupg` (this deletes your identity)

---

## 9️⃣ Backup (DO THIS ONCE)

Backup private key:

```bash
gpg --export-secret-keys --armor ABCD1234EFGH5678 > gpg-private-backup.asc
```

Store it **offline** (USB, encrypted drive).

---

## 🔑 TL;DR checklist

```bash
gpg --full-generate-key
gpg --list-secret-keys
gpg --armor --export KEYID
git config --global commit.gpgsign true
```
